Created by https://github.com/rubbertoe98

I edited the script so you can't carry people if you are death.

Requirements: mythic_notify

![image](https://user-images.githubusercontent.com/73753618/120633755-c96eee80-c46a-11eb-91ad-ba038f7e19b4.png)
